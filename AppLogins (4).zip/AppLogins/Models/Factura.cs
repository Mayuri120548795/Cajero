﻿namespace AppLogins.Models
{
    public class Factura
    {

        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public int IdCliente { get; set; }
        public double Total { get; set; }
        public double Iva { get; set; }
        public double SubTotal { get; set; }
        public string Estado { get; set; }
        public DateTime FechaCreacion { get; set; }

        public Cliente Cliente { get; set; }
    }
}
