﻿namespace AppLogins.ViewModels
{
    public class EditarUsersVM
    {

        public int Id { get; set; }
        public string Clave { get; set; }
        public string NombreUsuario { get; set; }
        public string Rol { get; set; }
        public string Estado { get; set; }

    }
}
