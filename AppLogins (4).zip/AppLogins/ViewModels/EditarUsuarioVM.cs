﻿namespace AppLogins.ViewModels
{
    public class EditarUsuarioVM
    {
        public int IdUsuario { get; set; }
        public string NombreCompleto { get; set; }
        public string Correo { get; set; }
        public string Clave { get; set; }
    }
}
