﻿namespace AppLogins.ViewModels
{
    public class LoginVM
    {

        public string Correo {  get; set; } 
        public string Clave { get; set; }
    }
}
