﻿using AppLogins.Models;

namespace AppLogins.ViewModels
{
    public class MostrarTipoProductoVM
    {

        public List<TipoProducto> TipoProducto { get; set; }
        public string Titulo { get; set; }
        // Puedes agregar más propiedades según sea necesario para tu vista


    }
}
