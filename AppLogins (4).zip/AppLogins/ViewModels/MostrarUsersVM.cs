﻿using AppLogins.Models;
using System.Collections.Generic;

namespace AppLogins.ViewModels
{
    public class MostrarUsersVM
    {
        public List<Users> Users { get; set; }
        public string Titulo { get; set; }
        // Puedes agregar más propiedades según sea necesario para tu vista


    }
}
