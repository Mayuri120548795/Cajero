﻿using AppLogins.Models;

namespace AppLogins.ViewModels
{
    public class MostrarUsuarioVM
    {
        public List<Usuario> Usuarios { get; set; }
        public string Titulo { get; set; }
        // Puedes agregar más propiedades según sea necesario para tu vista
    }
}
