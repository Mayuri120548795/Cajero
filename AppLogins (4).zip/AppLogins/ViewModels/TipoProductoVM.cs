﻿namespace AppLogins.ViewModels
{
    public class TipoProductoVM
    {
        public int Id { get; set; }
        public string Tipo { get; set; }
        public string Estado { get; set; }
        public DateTime FechaCreacion { get; set; }
    }
}
